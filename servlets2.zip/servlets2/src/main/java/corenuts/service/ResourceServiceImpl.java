package corenuts.service;

public class ResourceServiceImpl implements ResourceService {

}
