package corenuts.service;

public interface ResourceService {

}
